from setuptools import setup, find_packages

setup(
    name="adr1ja_diffusion2d",
    version="0.0.2",
    packages=find_packages(where="adr1ja_diffusion2d"),
)
